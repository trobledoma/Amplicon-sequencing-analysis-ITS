from . import seqDataClass
