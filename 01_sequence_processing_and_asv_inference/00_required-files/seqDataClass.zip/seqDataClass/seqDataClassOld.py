import pandas as pd
import numpy as np
import yaml
from zipfile import ZipFile
from biom.table import Table
from biom.util import biom_open
import copy

import plotly.graph_objects as go

"""
import argparse

parser = argparse.ArgumentParser(description='Preparing a barplot from phyloseq barplot data.')

parser.add_arglument('--taxonomy','-t', dest='TAX', type=str, help='Taxonomy file.', required=True)
parser.add_argument('--feature','-f', dest='FEAT', type=str, help='Feature (OTU) file.', required=True)
parser.add_argument('--mapping','-m', dest='MAP', type=str, help='Mapping file.', required=True)
parser.add_argument('--taxonomySep','-ts', dest='TAX_SEP', type=str, help='Taxonomy file separator [class default is TAB].')

args = parser.parse_args()

########################################################################################################################
"""

class seqObject():
    """
    This class represents a sequencing file object managing a mapping file, feature/otu file and taxonomy with some associated functions
    """
    def __init__(self,
                 mappingFile=None,
                 taxonomyFile=None,
                 featureFile=None,
                 mappingSep = '\t',
                 taxonomySep = '\t',
                 featureSep = '\t',
                 sampleNamesColumn="Sample",
                 taxonomyDatabase=None,
                 featureFormat="automatic",
                 featureColumnName="None",
                 featureRowName="",
                 taxonomyFormat=None):
        """
        Creates and organizes class variables from the input files.

        :param mappingFile: A file containing mapping file
            :type mappingFile: str
        :param taxonomyFile: A file containing the taxonomy with separate columns for taxonomic levels
            :type taxonomyFile: str
        :param featureFile: A file containing the feature/otu table with samples in columns and features/otus in rows
            :type featureFile: str
        :param mappingSep: Separator in the mapping file, default is '\t'
            :type mappingSep: char
        :param taxonomySep: Separator in the taxonomy file, default is '\t'
            :type taxonomySep: char
        :param featureSep: Separator in the feature/otu file, default is '\t'
            :type featureSep: char
        :param sampleNamesColumn: Name of the column containing sample names.
            :type sampleNamesColumn: str
        :param taxonomyDatabase: Selection of a database for a Silva taxonomy output (SILVA, RDP, GTDB, LTP, EMBL)
            :type taxonomyDatabase: str

        """

        print("Initializing data loading.")
        self.sampleName = sampleNamesColumn

        self.load_mapping(file=mappingFile, sep=mappingSep)
        self.load_taxonomy(file=taxonomyFile, sep=taxonomySep, database=taxonomyDatabase, taxonomyFormat=taxonomyFormat)
        self.load_feature(file=featureFile, sep=featureSep, format=featureFormat, featureColumnName=featureColumnName)

    def load_mapping(self, file, sep):
        """
        Loading the mapping file and formatting it.

        :param file: input mapping file
            :type file: str
        :param sep: separator character used in the mapping file
            :type sep: char
        :return: mapping file based dictionary
        """
        print("Loading mapping file")
        # Loading mapping file
        #self.mapDict = {}
        #with open(file, 'r') as f_map:
            # Loading a header of the file
        #    self.mapHeader = f_map.readline().split(sep)
        #    self.mapHeader[-1] = self.mapHeader[-1].rstrip()

            # Looking up a sample name column
            #if self.sampleName in self.mapHeader:
            #    name_pos = self.mapHeader.index(self.sampleName)
            #else:
            #    raise ValueError("Mapping file : Column '{0}' missing in mapping file. {0} is a mandatory field to identify sample names.".format(self.sampleName))

            # Parsing the file into a dictionary
            #for line in f_map:
            #    line = line.rstrip()
            #    line_list = line.split(sep)
            #    key = line_list[name_pos]
            #    line_list.pop(name_pos)

            #    self.mapDict[key] = line_list

            # Removing the sample name from the mapping
            #self.mapHeader.pop(name_pos)

        self.df_map = pd.read_csv(file, sep=sep)

    def load_taxonomy(self, file, sep, database, taxonomyFormat):
        """
        Loading the taxonomy file and formatting it
        :param file: Input taxonomy file.
            :type file: str
        :param sep: Separator character used in the taxonomy file.
            :type sep: char
        :return: taxonomy based dictionary
        """
        print("Loading taxonomy")

        # If file ending is .qza, extract taxonomic table from the file and proceed to treat it regularly
        if file[-4:] == ".qza":
            file = self._load_qiime_zip(file, "taxonomy.tsv")

        self.taxDict = {}

        # Switch cases functions for different inputs
        def name_fun(header):
            print("Recognizing a 'name' column.")
            name_pos = header.index("Name")
            format = "custom"
            return name_pos, format

        def qiime2_fun(header):
            print("Recognizing a Qiime2 format.")
            name_pos = header.index("Feature ID")
            format = "Qiime2"
            return name_pos, format

        def mothur_fun(header):
            print("Recognizing a mothur format.")
            name_pos = 0
            format = "mothur"
            return name_pos, format

        def silva_fun(header):
            print("Recognizing a silva format.")
            name_pos = 0
            format = "silva"
            return name_pos, format

        def dada2_fun(header):
            print("Recognizing a DADA2 format.")
            name_pos = 0
            format = "dada2"
            return name_pos, format

        # Guessing the format of the first cell that should contain the id od the taxonomy columns
        def format_cases(argument):
            switcher = {
                "Name": name_fun,
                "Feature ID": qiime2_fun,
                "Otu1": mothur_fun,
                '"job_id"': silva_fun,
                '"name"' : silva_fun,
                '""' : dada2_fun
            }
            func = switcher.get(argument, lambda argument: (0, 0))
            output = func(argument)
            return output

        with open(file, 'r') as f_tax:
            # Loading a header of the file
            self.taxHeader = f_tax.readline().split(sep)
            self.taxHeader[-1] = self.taxHeader[-1].rstrip()

            # Retrieving format of the data file and the position of the name column (just in case this is random)
            name_pos, format = format_cases(self.taxHeader[0])
            if taxonomyFormat:
                format = taxonomyFormat

            if format == 0:
                raise ValueError("Taxonomy file : Unknown format of a taxonomy file. Supported formats are: \n "
                                 "Qiime2 format with a 'Feature ID' column and a 'Taxon' column. \n"
                                 "Silva format with a 'name' column and taxonomy split in separate columns. \n"
                                 "DADA2 format with an unnamed sample column and separate columns for each taxonomic category.")

            ## This should be in the new custom function
            if format == "custom":
                # Parsing the file into a dictionary
                for line in f_tax:
                    line = line.rstrip()
                    line_list = line.split(sep)
                    key = line_list[name_pos]
                    line_list.pop(name_pos)
                    # Adding the OTU name at the end instead of the beginning of the list for the multiple index later
                    line_list.append(key)

                    self.taxDict[key] = line_list

                # Removing the sample name from the mapping
                self.taxHeader.pop(name_pos)
            elif format == "seqDataClass":
                self.df_tax = pd.read_csv(file, sep=sep)

            def line_formatting(line):#, name_pos, taxonomy_pos):
                #line = line.rstrip()
                #line = line.split('"'+sep+'"')
                # Replacing redundant quotation marks
                #line = [(lambda a: a.replace('"', ''))(a) for a in line]
                #key = line[name_pos]

                line_list = []
                try:
                    for taxon in line[1].split(";"):
                            # Removing crazy irregular taxon levels that RDP got creative with. Thanks Obama.
                            if taxon[-4:] == "idae" or taxon[-5:] == "ineae":
                                #print(f"skipping {entry}")
                                continue
                            taxon = taxon.split('(')[0]
                            if len(taxon) != 0:
                                line_list.append(taxon)
                except:
                    raise ValueError("It was not possible to process taxonomy line : {}. Exiting program. "
                                     "Check the taxonomy file.".format(line))

                if len(line_list) < 6:
                    filler = ["Unclassified"]*(6 - len(line_list))
                    line_list = line_list + filler

                if len(line_list) > 7:
                    print(line_list)

                self.taxDict[line[0]] = line_list
                return 1

            if format == "mothur":

                line = self.taxHeader
                line = sep.join(line)
                line_formatting(line)

                self.taxHeader = ["feature-name", "Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species"]

                #for line in f_tax:
                #    line_formatting(line, name_pos=0, taxonomy_pos=1)

            # Silva csv format
            if format == "silva":
                # Choosing the right database
                if database in ["EMBL", "GTDB", "LTP", "RDP", "SILVA"]:
                    if database == "EMBL":
                        tax_column = "lca_tax_embl_ebi_ena"
                        print("Using the EMBL database.")
                    if database == "GTDB":
                        tax_column = "lca_tax_gtdb"
                        print("Using the GTDB database.")
                    if database == "LTP":
                        tax_column = "lca_tax_ltp"
                        print("Using the LTP database.")
                    if database == "RDP":
                        tax_column = "lca_tax_rdp"
                        print("Using the RDP database.")
                    if database == "SILVA":
                        tax_column = "lca_tax_slv"
                        print("Using the SILVA database.")
                else:
                    raise Exception("Wrong database for Silva output was defined. Please select one from : GTDB, RDP, SILVA, "
                                    "LTP, EMBL")

                # Correcting redundant set of quotation marks
                newHeader = []
                for entry in self.taxHeader:
                    newHeader.append(entry.replace('"', ''))
                self.taxHeader = newHeader

                # Retrieving sequence identifier name
                if 'sequence_identifier' in self.taxHeader:
                    name_pos = self.taxHeader.index("sequence_identifier")
                elif "name" in self.taxHeader:
                    name_pos = self.taxHeader.index("name")
                else:
                    raise Exception("Could not find the Feature identifier column. Should be either 'sequence_identifier"
                                    " or 'name'. Correct that, please. Thank you.")
                database_pos = self.taxHeader.index(tax_column)

                #for line in f_tax:
                #    line_formatting(line, name_pos=name_pos, taxonomy_pos=database_pos)

                silva_tax = pd.read_csv(file, sep=sep)
                tax_cols = list(silva_tax.columns)
                tax_cols.pop(name_pos)
                tax_cols.pop(tax_cols.index(tax_column))

                silva_tax.drop(tax_cols, axis=1, inplace=True)

                import math

                for i,row in silva_tax.iterrows():
                    line_formatting(row)

                self.taxHeader = ["feature-id", "Kingdom", "Phylum", "Class", "Order", "Family", "Genus"]#, "Species"]

            if format == "dada2":
                self.df_tax = pd.read_csv(file)
                #name_list = []
                #for i,entry in enumerate(df_tax.iloc[:,0]):
                #    name_list.append("ASV_" + str(i))

                columns = list(self.df_tax.columns)
                columns[0] = "feature-id"
                self.df_tax.columns = columns
                # Renaming ASVs for convenience
                #df_tax.iloc[:,0] = name_list
                self.df_tax.fillna("Unclassified", inplace=True)

            # We will re-open the file later in the appropriate function
        if format == "Qiime2":
            self.qiime2_taxonomy(file, name_pos, sep)

    def qiime2_taxonomy(self, file, name_pos, sep):
        """
        Loading the taxonomy file in the Qiime2 format and re-formatting it
        :param file: Input taxonomy file.
            :type file: str
        :param name_pos: Position of the name column (column with the taxon codes - hash codes in Qiime2)
            :type file: int
        :param sep: Separator character used in the taxonomy file.
            :type sep: char
        :return: taxonomy based dictionary
        """
        # Removing confidence column from the tax header.
        #self.taxHeader.pop(self.taxHeader.index("Confidence"))
        #self.taxHeader.pop(self.taxHeader.index("Taxon"))
        self.taxHeader = ["feature-id", "Kingdom", "Phylum", "Class", "Order", "Family", "Genus"]

        # Loading tables directly
        with open(file, 'r') as f_in:
            header = f_in.readline().split(sep)
            if "Taxon" in header:
                tax_val_index = header.index("Taxon")
            else:
                raise ValueError("Column 'Taxon' not found in the taxonomy file. This may be due to different version "
                                 "of Qiime2 used.")

            # This is to get an idea of distribution of taxonomic lengths (depth) within the tax file. For debugging.
            #tax_len_dict = {1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0, 10:0, 11:0, 12:0, 13:0, 14:0, 15:0}

            for line in f_in:
                line = line.split('\t')
                # Taxon identifier code (name)
                key = line[name_pos]
                tax_value_raw = line[tax_val_index].split(';')
                # Cleaning the names
                tax_value = []
                for value in tax_value_raw:
                    tax_value.append(value.split('_')[-1])

                # Filling in the empty unidentified levels
                # For now the taxonomic depth is hard-coded at 6
                tax_len_level = 6
                # This is again distribution of taxonomic lengths (depths) within the file. For debugging.
                #tax_len_dict[len(tax_value)] = tax_len_dict[len(tax_value)] + 1

                # First trimming the lengths
                if len(tax_value) > tax_len_level:
                    tax_value = tax_value[0:tax_len_level]
                # Now filling in the empty spaces
                if len(tax_value) < tax_len_level:
                    how_much_shorter = tax_len_level - len(tax_value)
                    tax_value = tax_value + ["Unidentified"]*how_much_shorter

                self.taxDict[key] = tax_value

            #import sys
            #sys.exit()

    def load_feature(self, file, sep, format, featureColumnName):
        """
        Loading the feature/otu file and creating the final multi indexed table

        :param format: Specification of an input format (Qiime2, dada2, custom)
            :type format: str
        :param file: Input mapping file.
            :type file: str
        :param sep: Separator character used in the feature/otu file.
            :type sep: char
        :return: Finalized multi indexed table containing both taxonomy and mapping file information.
        """

        # If file ending is .qza, extract table from a biom hdf5 file
        if file[-4:] == ".qza":
            table_hdf5  = self._load_qiime_zip(file, "feature-table.biom")
            with biom_open(table_hdf5) as f:
                table_biom = Table.from_hdf5(f)

                self.data = table_biom.to_dataframe(dense=True)
        elif format == "automatic":
            with open(file, 'r') as f_in:
                line = f_in.readline()
                if line == "# Constructed from biom file\n":
                    format = "Qiime2"
                if len(line.split(',')[0].replace('"', '')) == 0: # or len(line.split(",")[1]) > 100:
                    format = "dada2"
                else:
                    format = "custom"

        ######################################
        # Custom format
        ######################################
        if format == "custom":
            self.data = pd.read_csv(file, sep=sep)
            if featureColumnName:
                try:
                    self.data.index = self.data[featureColumnName]
                    self.data = self.data.drop([featureColumnName], axis=1)
                except:
                    "Error: featureColumName does not match a colum in an input file"
            else:
                try:
                    self.data.index = self.data["#OTU ID"]
                    self.data = self.data.drop(["#OTU ID"], axis=1)
                    self.data.index = self.data.index.rename("ID")
                except:
                    try:
                        self.data.index = self.data["Unnamed: 0"]
                        self.data = self.data.drop(["Unnamed: 0"], axis=1)
                        self.data.index = self.data.index.rename("ID")
                    except:
                        raise ValueError(
                            "ID/OTU column not found. Check the OTU name format.")

            self.data.columns = self.data.columns.rename(self.sampleName)

            '''
            # Renaming otus from OTU1 to OTU0001 etc.
            new_rownames = []
            # Retrieving number of characters in the longest feature name
            feature_name_max_len = self.data.index.str.len().max()
            # extracting a feature/otu name
            name_len = 0
            for letter in self.data.index[0]:
                if letter.isdigit():
                    break
                name_len = name_len + 1
            feature_name = self.data.index[0][0:name_len]
            for row in self.data.index:
                if len(row) < feature_name_max_len:
                    # Stands for "Otu..."
                    row_number = row[name_len:]
                    zeros = (feature_name_max_len - name_len - len(row_number)) * '0'
                    new_row = feature_name + zeros + row_number
                new_rownames.append(new_row)

            self.data.index = new_rownames
            
            for entry in self.taxDict:
                if len(entry) < feature_name_max_len:
                    row = entry[3:]
                    zeros = (feature_name_max_len - 3 - len(row)) * '0'
                    row = "Otu" + zeros + row
                    self.taxDict[row] = self.taxDict.pop(entry)
            '''

            # Sorting the otu table
            #self.data = self.data.sort_index()



        ######################################
        # Qiime2 format
        ######################################
        if format == "Qiime2":
            # Skipping the first line of the table and using the second as a header
            self.data = pd.read_csv(file, sep=sep, header=1)
            self.data.index = self.data["#OTU ID"]
            self.data = self.data.drop(["#OTU ID"], axis=1)

            self.data.columns = self.data.columns.rename(self.sampleName)


        ######################################
        # DADA2 format
        ######################################
        if format == "dada2":
            self.data = pd.read_csv(file, sep=sep, index_col=0)
            self.data = self.data.transpose()

            # Sorting the rows to match the feature table
            #sorter = list(self.data.index)
            #sorterIndex = dict(zip(sorter, range(len(sorter))))
            #self.df_tax["Rank"] = self.df_tax["feature-id"].map(sorterIndex)

            #self.df_tax.sort_values(["Rank"], ascending=True, inplace=True)
            #del self.df_tax["Rank"]
            #tax_idx = pd.MultiIndex.from_frame(self.df_tax)

            #self.data.index = tax_idx

        ######################################
        # seqDataClass format
        ######################################
        if format == "seqDataClass":
            self.data = pd.read_csv(file, sep=sep, index_col=0)

        if self.taxDict:
            for entry in self.taxDict:
                if len(self.taxDict[entry]) != 6:
                    print(entry)
                    print("Tax Dictionary entry wrong legnth! It should be 6 and is : {}".format(len(self.taxDict[entry])))
                break
            # Adding a multi index
            self.df_tax = pd.DataFrame.from_dict(self.taxDict, orient='index')
            # Inserting column in the first place of the table
            self.df_tax.insert(0, "feature-id", self.df_tax.index)
            self.df_tax.drop(labels=6, axis=1, inplace=True)
            self.df_tax.columns = ["feature-id", "Kingdom", "Phylum", "Class", "Order", "Family", "Genus"]

        sorter = list(self.data.index)
        sorterIndex = dict(zip(sorter, range(len(sorter))))
        self.df_tax["tax_rank"] = self.df_tax["feature-id"].map(sorterIndex)
        self.df_tax.sort_values(["tax_rank"], ascending=True, inplace=True)
        #del self.df_tax["Rank"]
        #df1 = df1.transpose()

        if len(sorter) > len(self.df_tax.index):
            #TODO: This bit is probably broken at the moment
            for entry in self.df_tax.index:
                sorter.pop(sorter.index(entry))
            raise ValueError("The following features were not present in the taxonomy : {}. Please add them.".format(sorter))
        elif len(sorter) < len(self.df_tax.index):
            print("Taxonomy has some redundant features. Attempting to prune these.")
            for entry in self.df_tax["feature-id"]:
                if entry not in sorter:
                    self.df_tax = self.df_tax[self.df_tax['feature-id'] != entry]


        # Sanity check that all features in sorter (feature file) are also in self.df_tax_index (taxonomy file)
        print("Matching features between feature file and taxonomy file.")
        #for entry in self.df_tax.index:
        for entry in self.df_tax["feature-id"]:
            if entry not in sorter:
                raise ValueError("Feature file and taxonomy file features mismatch at {}".format(entry))
        print("Features match.")

        # Renaming the data frame columns names (but not for DADA2, which doesn't produce taxDict
        #if self.taxDict:
        #    new_columns = self.taxHeader[0:len(self.df_tax.columns)]
        #    #new_columns.append("tax_rank")
        #    self.df_tax.columns = new_columns


        tax_index = pd.MultiIndex.from_frame(self.df_tax)

        # Setting the taxonomy indices
        self.data.index = tax_index

        # Arranging the values of the Multiindex according to the data frmae

        #self.df_map = pd.DataFrame.from_dict(self.mapDict)
        #self.df_map = self.df_map.transpose()
        #self.df_map["sample-id"] = list(self.df_map.index)
        # Sorting based on the columns present in the feature table
        sorter = list(self.data.columns)
        sorterIndex = dict(zip(sorter, range(len(sorter))))
        self.df_map["map_rank"] = self.df_map["sample-id"].map(sorterIndex)
        self.df_map.sort_values(["map_rank"], ascending=True, inplace=True)

        #del self.df_map["Rank"]
        # Creating a data frame from the map ditionary
        #df2 = df2.transpose()
        # Setting the names of columns
        #self.mapHeader.append("sample-id")
        #self.mapHeader.append("map_rank")
        #self.df_map.columns = self.mapHeader

        del self.df_map["map_rank"]

        map_index = pd.MultiIndex.from_frame(self.df_map)

        self.data.columns = map_index

    # Loading a file from qiime zip archive and returning its position
    def _load_qiime_zip(self, archive, file):
        with ZipFile(archive, 'r') as zip:
            for entry in zip.filelist:
                #print(entry.filename.split('/')[-1])
                if entry.filename.split('/')[-1] == file:
                    #print(entry.filename.split('/')[1])
                    table = zip.extract(entry.filename, path="/tmp/")
        return table

    def rarefy_to_even_depth(self, seqDepth, seed):
        """
        Rarefaction to even depth is a normalization method in which an equal number of sequences is randomlz retrieved
         from each sample to form a new feature/OTU table with equal sequencing depths. If some samples fall bellow a defined
         depth of sequencing treshold, they are removed from the dataset.

        :param seqDepth: A number of sequences that are randomly sampled from the dataset.
            :type seqDepth: int
        :param seed: A random seed value to maintain repeatability.
            :type seed: int
        :return: A rarefied feature/OTU table is saved in place of the original table.
        """
        rndSeed = np.random.RandomState(seed)

        sampleSums = np.sum(self.data, axis=0)
        nSpecies = self.data.shape[0]

        for i, column in self.data.iteritems():

            # If total number of sequences is lower than sequencing depth, remove the sample
            if column.sum() < seqDepth:
                sampleName = column.name[self.data.columns.names.index(self.sampleName)]
                print("Sample {} was removed from the dataset because it contains insufficient amount of sequences ({}).".format(sampleName, column.sum()))

                self.remove_sample(category=self.sampleName, sample=sampleName)
            else:
                relativeFreq = column.values/sampleSums[i]

                randomChoice = rndSeed.choice(a=nSpecies, size=seqDepth, p=relativeFreq)
                self.data[i] = np.bincount(randomChoice, minlength=nSpecies)

        # Removing rows that no longer contain any features/OTUs
        print("Removing {} features/OTUs that no longer appear in any sample.".format(sum(self.data.sum(axis=1) == 0)))
        self.data = self.data[self.data.sum(axis=1) != 0]

    def remove_sample(self, sample, category):
        catPosition = self.data.columns.names.index(category)

        if sample in self.data.columns.get_level_values(level=catPosition):

            self.data = self.data.drop(level=catPosition, columns=sample)
            self.data.columns = self.data.columns.remove_unused_levels()
        else:
            print("Error: Trying to remove {}, which is not available among samples.".format(sample))
            quit()

    def add_multiindex_index(self, dict, label):
        # Constructing a data frame from the supplied dictionary
        df2 = pd.DataFrame.from_dict(dict, orient="index", columns=[label])
        # Transforming multiindex into a data frame
        df1 = self.data.index.to_frame()
        df1.index = df1.ID
        # Joining the two data frames (adding the new column)
        df1 = df1.join(df2)
        # Creating a new MultiIndex from the new data frame
        newIndex = pd.MultiIndex.from_frame(df1)

        self.data.index = newIndex

    def add_multiindex_column(self, dict, label):
        df1 = self.data.columns.to_frame()

        nameColNumber = self.data.columns.names.index(self.sampleName)
        df1.index = df1.iloc[:,nameColNumber]

        names = list(df1.Name)
        newDict = {}
        i = 0
        for name in names:
            newDict[name] = "Something" + str(i)
            i = i + 1

        df2 = pd.DataFrame.from_dict(dict, orient="index", columns=[label])

        df1 = df1.join(df2)

        newIndex = pd.MultiIndex.from_frame(df1)

        self.data.columns = newIndex

    def _add_multiindex_column(self, input_df, dict):
        # More general version of add_multiindex_column
        df1 = input_df.columns.to_frame()
        df1.reset_index(drop=True, inplace=True)

        for key in dict:
            df2 = pd.DataFrame.from_dict(dict)
            df1 = df1.join(df2)

        newIndex = pd.MultiIndex.from_frame(df1)

        input_df.columns = newIndex

        return input_df

    def add_feature_parameter(self, yamlParamDictFile, paramName):
        with open(yamlParamDictFile, 'r') as stream:
            try:
                paramDict = yaml.load(stream)
            except yaml.YAMLError as exc:
                print(exc)

        self.add_multiindex_index(dict=paramDict, label=paramName)

    def add_column_from_dict(self, yamlDictFile, label):
        with open(yamlDictFile, 'r') as stream:
            try:
                valueDict = yaml.load(stream)
            except yaml.YAMLError as exc:
                print(exc)

        otuValues = self.data.index.get_level_values("OTU")

        output = []
        for value in otuValues:
            output.append(valueDict[value])

        idx = pd.IndexSlice

        #self.data.loc[:,idx[label, label]] = output
        self.data[label, label] = output

    def extract_features_csv(self, fileName, sep = ',', level="feature-id"):
        # Flattening the data frame's multiindex for easier downstream analysis
        output = self.data.copy()
        output.columns = output.columns.get_level_values(self.sampleName)
        output.index = output.index.get_level_values(level)

        #del output.index.name
        #del output.columns.name

        output.to_csv(path_or_buf=fileName, sep=sep)

    def extract_rep_seq(self, filename, renameFeatures=True):
        # This function extract representative sequences and renames the
        with open(filename, 'w') as f_out:
            name = "feature"
            name_list = []
            for i,entry in enumerate(self.data.index.get_level_values("feature-id")):
                f_out.write('>' + name + str(i) + '\n')
                f_out.write(entry + '\n')
                name_list.append(name + str(i))

        if renameFeatures:
            # Renaming the oridinal dataset as well
            tax_index = self.data.index.to_frame(index = False)
            tax_index["feature-id"] = name_list
            tax_idx = pd.MultiIndex.from_frame(tax_index)
            self.data.index = tax_idx

    def extract_taxonomy(self, filename, sep=','):
        output = self.data.copy()
        output = output.index.to_frame(index=False)
        output.to_csv(filename, sep=sep, index=False)

    def simplify_table(self, tax_level, map_level=None):
        """
        Simplifying a table by summarizing it to a defined taxonomic level and one or more levels of metadata.

        :param tax_level: Desired taxonomic level of the outcome. All the lower levels will be summarized in each
        category.
            :type tax_level: str
        :param map_level: Desired level or a list of levels to which the data should be subset. All finer categories
        will be added together
            :type map_level: char
        :return: simplified table
        """
        if map_level:
            if isinstance(map_level, str):
                df1 = self.data.copy()
                df1 = df1.sum(level=tax_level, axis=0)
                # Summarising over taxonomic groups and mapping categories provided
                df1 = df1.sum(level=map_level, axis=1)

            if isinstance(map_level, list):
                '''
                Table simplification
                Group and sum each of the desired columns/categories effectively removing all other levels of metadata.
                Resulting data frame is left with only the columns levels in the map_level list.
                '''

                df1 = self.data.groupby(level=map_level, axis=1).sum()
                df1 = df1.sum(level=tax_level, axis=0)
                # Groupping all rows from the desired taxonomic level and summing them up.
                #df1 = df1.groupby(level=tax_level, axis=0).sum()

        try:
            return df1
        except:
            raise Exception("Map level not specified. Identify 'level' as a groupping value.")

    def colour_library(self, code, length=None):

        bright_palette = ["#ffd37f","#ffa700","#7f5300",
                          "#7fc3a1","#008744","#004322",
                          "#b18db3","#641B67","#320d33",
                          "#7fabf3","#0057e7","#002b73",
                          "#ea968f","#d62d20","#6b1610",
                          "#c3a17f","#874400","#432200",
                          "#c37fa1","#870043","#430021"]

        def retrieve_longer_palettes(palette, length):
            output = []
            n = len(palette)
            for i in range(length):
                j = i % n
                output.append(palette[j])

            return output

        if length is not None:
            bright_palette = retrieve_longer_palettes(palette=bright_palette, length=length)

        output = {"bright_palette": bright_palette}

        if isinstance(code, list):
            return code
        else:
            if code not in output:
                raise ValueError("Colour code not found. Currently available options: {}".format(output))
            return output[code]

    def copy(self):
        return copy.deepcopy(self)

    def stacked_barplot(self,
                        tax_level,
                        map_level,
                        treshold_mean=0.001,
                        plotter="plotly",
                        x_axis_order=None,
                        subplot_titles=None,
                        colors="bright_palette",
                        plot_theme: object = None,
                        width=1200,
                        height=600):

        """
        Plotting a stacked barplot using plotly (for now) plotting engine and streamlined subsettig options.

        :param tax_level: Desired taxonomic level of the outcome. All the lower levels will be summarized in each
        category.
            :type tax_level: str
        :param map_level: Desired level or a list of levels to which the data should be subset. All finer categories
        will be added together
            :type map_level: char
        :param treshold_mean: Abundance treshold for considering a group 'Low abundance'. This helps to declutter
        the resulting plots. Should be a number lower then 1, default value is 0.001.
            :type treshold_mean: num
        :param x_axis_order: Forces order of the categorical elements of the X axis.
            :type x_axis_order: none or list of str
        :param subplot_titles: Names of the subplots.
            :type subplot_titles: none or list of str
        :param colors: Name of a color palette from the colour_library.
            :type colors: str
        :param plot_theme: Plotly theme for the plot. One of the following :'ggplot2', 'seaborn', 'simple_white',
        'plotly', 'plotly_white', 'plotly_dark', 'presentation', 'xgridoff', 'ygridoff', 'gridon', 'none']
            :type plot_theme: str
        :param width: Width of the final plot in pixels.
            :type width: int
        :param height: Height of the final plot in pixels.
            :type height: int
        :return: simplified table
        """

        df1 = self.simplify_table(tax_level=tax_level, map_level=map_level)

        colSum = df1.sum(axis=0)

        df1 = df1.div(colSum)

        # If threshold mean is defined, summarise low abundance taxa in a 'low abundance' category
        if treshold_mean:
            lowAbundance = df1.loc[df1.mean(axis=1) < treshold_mean, :].sum()
            la = lowAbundance.to_frame(name="Low abundance")
            la = la.transpose()

            df1 = df1.loc[df1.mean(axis=1) > treshold_mean, :]
            df1 = df1.append(la)

            colSum = df1.sum(axis=0)
            df1 = df1.div(colSum)
        # If map level is just a string, use basic plotting with no subplots
        if isinstance(map_level, str):
            '''
            df1 = self.data.copy()
            # Summarising over taxonomic groups and mapping categories provided
            df1 = df1.sum(level=tax_level, axis=0)
            df1 = df1.sum(level=df1 = self.data.copy()map_level, axis=1)
            '''

            df1 = df1.sort_index(axis=0)

            if plotter == "plotly":

                #df1 = df1.reset_index()
                #df1 = df1.melt(id_vars="index")
                if x_axis_order:
                    df1 = df1[x_axis_order]
                    #cat_dtype = pd.api.types.CategoricalDtype(categories=x_axis_order, ordered=True)
                    #df1.columns = df1.columns.astype(cat_dtype)
                    #df1 = df1.reindex(sorted(df1.columns), axis=1)
                    #df1 = df1.sort_values(df1.columns)

                #import plotly.express as px
                #fig = px.bar(df1, x=map_level, y="value", color="index")
                import plotly.graph_objs as go

                color_list = self.colour_library(colors, length=df1.shape[0])
                fig = go.Figure()

                for row, colour in zip(df1.index, color_list):

                    try:
                        x = df1.columns.categories
                    except:
                        x = df1.columns.to_list()

                    fig.add_trace(go.Bar(x=x,
                                         y=df1.loc[row, :],
                                         name=row,
                                         marker_color=colour
                                         ),
                                  )

                fig.update_layout(title=dict(text=f'Relative abundance per {map_level}'),
                                  barmode='stack',
                                  width=width,
                                  height=height,
                                  template=plot_theme,
                                  xaxis_type="category")
            return fig
        # If map level is a list, proceed to a plotting with subplots
        if isinstance(map_level, list):

            if not ((x_axis_order is None) or isinstance(x_axis_order, dict)):
                raise Exception("Error: Type of x_axis_order must be either None (not included) or dictionary. Provided value is {}".format(type(x_axis_order)))

            if x_axis_order:
                # In order to make the column names ordered, we need to create a new column index to replace the old one
                # This is done by copying the old column
                df_cols = df1.columns.to_frame()
                df_cols.reset_index(drop=True, inplace=True)
                for key in x_axis_order:
                    cat_dtype = pd.api.types.CategoricalDtype(categories=x_axis_order[key], ordered=True)
                    df_cols[key] = df_cols[key].astype(cat_dtype)

                newIndex = pd.MultiIndex.from_frame(df_cols)

                df1.columns = newIndex

            # Loading a necessary plotly library for construction of subplots.
            from plotly.subplots import make_subplots
            import plotly.graph_objs as go
            #print(df1)

            map_dict = {}
            for level in map_level:
                map_dict[level] = {}
                map_level_vals = df1.columns.get_level_values(level).unique()
                for value in map_level_vals:
                    map_dict[level][value] = df1.xs(value, level=level, axis=1)

            ncols = len(df1.columns.get_level_values(map_level[0]).unique())

            if subplot_titles:
                if len(subplot_titles) != ncols:
                    raise ValueError("Wrong amount of provided supblot titles (subplot_titles)."
                                     " Provided {} titles, but attempting to plot {} plots.".format(len(subplot_titles), ncols))

                fig = make_subplots(rows=1, cols=ncols, subplot_titles=subplot_titles)
            else:
                block_names = df1.columns.get_level_values(map_level[0]).unique()
                block_names = block_names.to_list()
                fig = make_subplots(rows=1, cols=ncols, subplot_titles=block_names)


            color_list = self.colour_library(colors)

            # Looping over the first user supplied level
            for level in map_level:
                # Looping through the values of the first level supplied
                # If a provided set is categorical, use categories
                try:
                    categories = df1.columns.get_level_values(level).categories
                # Otherwise use just unique values
                except:
                    categories = df1.columns.get_level_values(level).unique()
                for i, category in enumerate(categories):
                    #print("Category: {}".format(category))
                    # Looping through taxonomic categories (map_dict...index is taxonomy informations)
                    # Adding colour information from the provided color_list

                    #df_temp = map_dict[level][category]
                    df_temp = df1.xs(key=category, axis=1, level=level)
                    df_temp.sort_index(axis=1, inplace=True)
                    for row, color in zip(df_temp.index, color_list):
                        try:
                            x = df_temp.columns.categories
                        except:
                            x = df_temp.columns.to_list()
                        #print("i: {}, item: {}, color: {}".format(i, item, color))
                        fig.add_trace(go.Bar(x=x,
                                             y=df_temp.loc[row,:],
                                             name=row,
                                             marker_color=color
                                             ),
                                      row=1,
                                      col=i+1
                                      )

                fig.update_layout(title=dict(text='Relative abundance {} per {}'.format(map_level[0], map_level[1])),
                                  barmode='stack',
                                  width=width,
                                  height=height,
                                  template=plot_theme,
                                  xaxis_type="category")

                return fig
            #print(map_dict)


    #def NMDS(self, plotter="plotly"):




if __name__ == "__main__":

    plotly_template = "plotly_white"
    tax_database = "RDP"
    '''
    data = seqObject(mappingFile="/home/user/qiime/Zygophilum/dada2/metadata_DNA.csv",
                      taxonomyFile="/home/user/qiime/Zygophilum/dada2/DNA_dada2_taxonomy.csv",
                      featureFile="/home/user/qiime/Zygophilum/tax4fun/normalized_table_DNA.tsv",
                      mappingSep='\t',
                      taxonomySep=',',
                      featureSep='\t',
                      sampleNamesColumn="sample-id",
                      featureFormat="custom",
                      featureColumnName="feature-id")

    extract_rep_seq
    
    data = seqObject(mappingFile="/home/user/qiime/Zygophilum/dada2/metadata_DNA.csv",
                      taxonomyFile="/home/user/qiime/Zygophilum/dada2/DNA_dada2_taxonomy.csv",
                      featureFile="/home/user/qiime/Zygophilum/dada2/DNA_dada2_feature_table_nochim.csv",
                      mappingSep='\t',
                      taxonomySep=',',
                      featureSep=',',
                      sampleNamesColumn="sample-id",
                      featureFormat="dada2")


    #data.rarefy_to_even_depth(seqDepth=2948, seed=123)

    #data.save_features_csv("~/normalized_table_DNA.tsv", sep='\t')

    data.extract_rep_seq("/home/user/qiime/Zygophilum/trash_stuff/rep_seq.fasta")
    data.extract_taxonomy("/home/user/qiime/Zygophilum/trash_stuff/taxonomy_DNA.tsv", sep="\t")
    data.extract_features_csv("/home/user/qiime/Zygophilum/trash_stuff/feature_table_DNA.tsv", sep="\t")
    '''
    data = seqObject(mappingFile="/home/user/qiime/Zygophilum/dada2/metadata_DNA.csv",
                      taxonomyFile="/home/user/qiime/Zygophilum/trash_stuff/taxonomy_DNA.tsv",
                      featureFile="/home/user/qiime/Zygophilum/trash_stuff/feature_table_DNA.tsv",
                      mappingSep='\t',
                      taxonomySep='\t',
                      featureSep='\t',
                      sampleNamesColumn="sample-id",
                      featureFormat="seqDataClass",
                      taxonomyFormat="seqDataClass")
    '''
    colours = data.colour_library("bright_palette", 19)
    colours.pop(colours.index("#320d33"))

    fig = data.stacked_barplot(tax_level="Phylum",
                               map_level="stone",
                               plotter="plotly",
                               x_axis_order=["Marble", "Limestone", "Granite", "Sandstone", "Soil", "Air"],
                               colors=colours
                               )

    fig.update_layout(title=dict(text='Community in stone and soil'),
                      width=1000,
                      height=600,
                      # template="plotly_dark"
                      template=plotly_template
                      # template="simple_white"
                      )

    fig.show()

    
    data = seqObject(mappingFile="/home/user/qiime/biostone/metadata2.csv",
                              taxonomyFile="/home/user/qiime/biostone/Michela_aligned.csv",
                              featureFile="/home/user/qiime/biostone/OTU_table_gloria_renamed.csv",
                              mappingSep='\t',
                              taxonomySep=',',
                              featureSep=',',
                              sampleNamesColumn="sample-id",
                              taxonomyDatabase='RDP')
                                  
    data = seqObject(mappingFile="/home/user/sequencing/amplicon/een2/dada2/metadata_75RTM.tsv",
                                  taxonomyFile="/home/user/sequencing/amplicon/een2/dada2/silva_taxonomy/75RTM.csv",
                                  featureFile="/home/user/sequencing/amplicon/een2/dada2/75RTM/data_table.qza",
                                  taxonomySep=';',
                                  sampleNamesColumn="sample-id",
                                  taxonomyDatabase=tax_database)

    data_FPYJ6 = seqObject(mappingFile="/home/user/sequencing/amplicon/een2/dada2/metadata_FPYJ6.tsv",
                                        taxonomyFile="/home/user/sequencing/amplicon/een2/dada2/silva_taxonomy/FPYJ6.csv",
                                        featureFile="/home/user/sequencing/amplicon/een2/dada2/FPYJ6/data_table.qza",
                                        taxonomySep=';',
                                        sampleNamesColumn="sample-id",
                                        taxonomyDatabase=tax_database)



    print("een2 works")

    data = seqObject(mappingFile="/home/user/sequencing/amplicon/een/metadata.tsv",
                                  taxonomyFile="/home/user/sequencing/amplicon/een/een_aligned.csv",
                                  featureFile="/home/user/sequencing/amplicon/een/dada2/data_table.qza",
                                  taxonomySep=',',
                                  sampleNamesColumn="sample-id",
                                  taxonomyDatabase=tax_database)
    print("een works!")
    data = seqObject(mappingFile="/home/user/qiime/biostone/metadata2.csv",
                     taxonomyFile="/home/user/qiime/biostone/dada2/dada2_taxonomy.csv",
                     featureFile="/home/user/qiime/biostone/dada2/dada2_feature_table_nochim.csv",
                     taxonomySep=",",
                     featureSep=",",
                     sampleNamesColumn="sample-id",
                     taxonomyDatabase=tax_database)
    print("biostone works! (dada2)")
    
    '''

    '''
    data = seqObject(mappingFile="/home/user/qiime/biostone/seq_prep/metadata.tsv",
                      taxonomyFile="/home/user/qiime/biostone/seq_prep/dada2/taxonomic_classification/taxonomy.qza",
                      featureFile="/home/user/qiime/biostone/seq_prep/dada2/table.qza",
                      mappingSep='\t',
                      taxonomySep='\t',
                      featureSep='\t',
                      sampleNamesColumn="sample-id")

    print(data.data)
    
    data = seqObject(mappingFile="/home/user/qiime/een2/dada2/metadata_75RTM.tsv",
                      taxonomyFile= "/home/user/qiime/een2/dada2/silva_taxonomy/75RTM.csv",
                      featureFile="/home/user/qiime/een2/dada2/75RTM/data_table.qza",
                      taxonomySep='";"',
                      sampleNamesColumn="sample-id",
                      taxonomyDatabase=tax_database)

    data_75RTM = seqObject(mappingFile="/home/user/qiime/een2/dada2/metadata_75RTM.tsv",
                            taxonomyFile= "/home/user/qiime/een2/dada2/silva_taxonomy/75RTM.csv",
                            featureFile="/home/user/qiime/een2/dada2/75RTM/data_table.qza",
                            taxonomySep='";"',
                            sampleNamesColumn="sample-id",
                            taxonomyDatabase=tax_database)

    data_FPYJ6 = seqObject(mappingFile="/home/user/qiime/een2/dada2/metadata_FPYJ6.tsv",
                            taxonomyFile= "/home/user/qiime/een2/dada2/silva_taxonomy/FPYJ6.csv",
                            featureFile="/home/user/qiime/een2/dada2/FPYJ6/data_table.qza",
                            taxonomySep='";"',
                            sampleNamesColumn="sample-id",
                            taxonomyDatabase=tax_database)

    data_HVIHS = seqObject(mappingFile="/home/user/qiime/een2/dada2/metadata_HVIHS.tsv",
                            taxonomyFile= "/home/user/qiime/een2/dada2/silva_taxonomy/HVIHS.csv",
                            featureFile="/home/user/qiime/een2/dada2/HVIHS/data_table.qza",
                            taxonomySep='";"',
                            sampleNamesColumn="sample-id",
                            taxonomyDatabase=tax_database)
    
    # Merging data
    data.data = pd.merge(data_75RTM.data,data_FPYJ6.data, right_index=True, left_index=True, how="outer")
    data.data = pd.merge(data.data, data_HVIHS.data, right_index=True, left_index=True, how="outer")

    data.data.fillna(0, inplace=True)

    # Renaming samples
    cols_df = data.data.columns.to_frame()

    output = []
    for value in cols_df["sample-id"]:
        output.append("vzorek_" + str(value))

    cols_df["sample-id"] = output

    data.data.columns = pd.MultiIndex.from_frame(cols_df)

    data.data = data.data.xs(key="TRUE", level="Include", axis=1)

    data.data = data.data.xs(key="control", level="Type", axis=1)

    data.rarefy_to_even_depth(seqDepth=1200, seed=124)
    '''
    '''
    data = seqObject(mappingFile="/home/user/qiime/een2/dada2/metadata_75RTM.tsv",
                     taxonomyFile="/home/user/qiime/een2/dada2/silva_taxonomy/75RTM.csv",
                     featureFile="/home/user/qiime/een2/dada2/75RTM/data_table.qza",
                     mappingSep = '\t',
                     taxonomySep = '";"',
                     featureSep = '\t',
                     sampleNamesColumn="sample-id",
                     taxonomyDatabase="LTP")
    '''
    '''
    fig = data.stacked_barplot(tax_level="Class",
                               map_level=["Group", "Individual"],
                               plotter="plotly",
                               plot_theme=plotly_template,
                               width=1500,
                               x_axis_order={
                                   "Individual": ["FS", "FS+Nutridrink", "FS+Renutryl", "FS+Ensure", "FS+Fresubin"]})

    fig.update_xaxes(tickangle=90)
    fig.update_layout(xaxis_type="category")

    fig.show()
    '''

    '''
    data = seqObject(mappingFile="/home/user/qiime/thalium/ThaliumCh.csv",
                     taxonomyFile="/home/user/qiime/thalium/thaliumH_otus.nr_v132.wang.taxonomy",
                     featureFile="/home/user/qiime/thalium/thaliumH_otutabMin.txt",
                     sampleNamesColumn="#OTU ID",
                     mappingSep=',')


    fig = data.stacked_barplot(tax_level="Phylum",
                               map_level=["Horizont", "#OTU ID"],
                               plotter="plotly",
                               # x_axis_order=list(data.data.columns.get_level_values("#OTU ID").sort_values())
                               )

    fig.show()
    '''


    '''
    data = seqDataClass.seqObject(mappingFile="/home/user/sequencing/amplicon/Zygophilum/analysis/mapping_file.csv",
                                  taxonomyFile="/home/user/sequencing/amplicon/Zygophilum/Taxonomy/taxonomy_cDNA.csv",
                                  featureFile="/home/user/qiime/een/analysis/exported/data_table.tsv",
                                  taxonomySep=',',
                                  sampleNamesColumn="Sample_name",
                                  mappingSep=',',
                                  featureSep='\t')
    '''
    '''Starting point
    fig = data.stacked_barplot(tax_level="Phylum",
                               map_level=["Pacient", "Description"],
                               plotter="plotly",
                               plot_theme="plotly_dark",
                               #x_axis_order=["Tyden_0", "Tyden_6", "Tyden_12"],
                               width=1800
                               )
    '''
    '''
    fig = data.stacked_barplot(tax_level="Phylum",
                               map_level=["Description", "Pacient"],
                               plotter="plotly",
                               x_axis_order=["Tyden_0", "Tyden_6", "Tyden_12"],
                               subplot_titles=["0. Týden", "6. Týden", "12. Týden"]
                               )
    '''

    #fig.show()

    #data.save_features_csv(fileName="/home/user/qiime/een/analysis/normalized_tab.csv")
    #data.NMDS()

    '''
    data.rarefy_to_even_depth(seqDepth=10000, seed=123)

    #data.add_otu_parameter(yamlParamDictFile="/home/adam/miseq/ReverseTrans/GC_content_plot/otus_GC.yaml", paramName="GC_content")

    #data.add_column_from_dict("/home/adam/miseq/ReverseTrans/GC_content_plot/otus_GC.yaml", "GC_content")

    data.stacked_barplot(tax_level="Phylum", map_level="Enzyme", treshold_mean=0.01)

    #data.remove_sample("Osnat037", category="Name")
    #data.remove_sample("DOOPE", category="Name")

    #data.save_otu_csv(finlename="testing_output.csv")

    print("Something to print")
    '''
